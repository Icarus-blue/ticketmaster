## About
This is Booking Management system.

## Github

Github repository: 

### `https://github.com/secstar1223/gymflex-fe-admin`

To clone repository, you can run:

### `git clone https://github.com/secstar1223/gymflex-fe-admin`

## Requirements

yarn v1.22.19
node 18.16.0

## Available Scripts

In the project directory, you can run:

### `yarn start`

Runs the app in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in your browser.

To build product, you can run:

### `yarn build`


