import { Box, Typography } from "@mui/material";
// import { useState } from "react";

const Reports = () => {
  // const [topMembers, setTopMembers] = useState([])
  // const theme = useTheme();

  return (
    <Box>
      <Typography variant="h5">Welcome to Reports Page!</Typography>
    </Box>
  );
};

export default Reports;
