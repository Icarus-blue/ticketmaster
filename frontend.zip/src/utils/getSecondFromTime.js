export const getSecondFromTime = (hr, min) => {
  return hr * 3600 + min * 60;
};
