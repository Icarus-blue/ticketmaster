const SERVER_ERROR = "Please check your internet connection";

export const strings = {
  SERVER_ERROR
}