export const _roles = ["admin", "trainee", "trainer", "localadmin", "staff"];
